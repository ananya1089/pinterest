from selenium.webdriver.common.by import By


class Profile_page:
    def __init__(self, driver):
        self.driver = driver
    profile_name = (By.CSS_SELECTOR, "//div[contains(text(),'Profiles')]")
    name_list = (By.CSS_SELECTOR, ".hs0.kzZ.mQ8.un8.C9i.TB_")

    def get_profile_name(self):
        self.driver.find_element(*Profile_page.profile_name)
    def get_name_list(self):
        s = self.driver.find_elements(*Profile_page.name_list)
        for i in s:
            print(len(i))