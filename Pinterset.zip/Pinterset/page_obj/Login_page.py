from selenium.webdriver.common.by import By


class Login_page:
    def __init__(self, driver):
        self.driver = driver

    login_btn = (By.CSS_SELECTOR, ".tBJ.dyH.iFc.sAJ.xnr.tg7.H2s")
    input_email = (By.CSS_SELECTOR, "#email")
    input_pass = (By.CSS_SELECTOR, "#password")
    submit_btn = (By.CSS_SELECTOR, "button[type='submit'] div[class='zI7 iyn Hsu']")

    def get_login_btn(self):
        return self.driver.find_element(*Login_page.login_btn)

    def get_input_email(self):
        return self.driver.find_element(*Login_page.input_email)

    def get_input_pass(self):
        return self.driver.find_element(*Login_page.input_pass)

    def get_submit_btn(self):
        return self.driver.find_element(*Login_page.submit_btn)
