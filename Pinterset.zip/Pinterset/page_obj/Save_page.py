from selenium.webdriver.common.by import By


class Save_page:
    def __init__(self, driver):
        self.driver = driver

    save_btn = (By.XPATH, "//div[contains(@class,'tBJ dyH iFc sAJ xnr tg7 H2s')]")
    follow_btn = (By.XPATH, "//div[contains(text(),'Follow')]")

    def get_save_btn(self):
        return self.driver.find_element(*Save_page.save_btn)

    def get_follow_btn(self):
        return self.driver.find_element(*Save_page.follow_btn)
