from selenium.webdriver.common.by import By


class Home_page:
    def __init__(self, driver):
        self.driver = driver

    search_index = (By.CSS_SELECTOR, "input[placeholder='Search']")
    search_click = (By.XPATH, "//div[@id='SuggestionGroup-Option-0-0']")
    click_of_index = (By.CSS_SELECTOR, "img[alt*='This contains an image of: Coder Life IPhone Wallpaper - IPhone Wallpapers']")
    

    def get_search_index(self):
        return self.driver.find_element(*Home_page.search_index)

    def get_search_click(self):
        return self.driver.find_element(*Home_page.search_click)

    def get_click_of_index(self):
        return self.driver.find_element(*Home_page.click_of_index)
