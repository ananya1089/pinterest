import time

from page_obj.Home_page import Home_page
from page_obj.Login_page import Login_page
from page_obj.Profile_page import Profile_page
from page_obj.Save_page import Save_page
from utilities.Base_Class import BaseClass


class Test_Main(BaseClass):
    def test_pinterest(self, get_username, get_password):
        login_page = Login_page(self.driver)
        login_page.get_login_btn().click()
        login_page.get_input_email().send_keys(get_username)
        login_page.get_input_pass().send_keys(get_password)

        login_page.get_submit_btn().click()
        home_page = Home_page(self.driver)
        home_page.get_search_index().send_keys("code")
        home_page.get_search_click().click()
        home_page.get_click_of_index().click()
        save_page = Save_page(self.driver)
        save_page.get_save_btn().click()
        save_page.get_follow_btn().click()
        time.sleep(10)
        self.driver.back()
        time.sleep(10)
        profile_page = Profile_page(self.driver)
        profile_page.get_profile_name().click()
        profile_page.get_name_list()
        time.sleep(10)


